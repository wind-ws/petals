/// 与人民币等价的 虚拟货币
/// 软妹币 模块
pub mod mint_rmb;

pub mod raise_fund;
