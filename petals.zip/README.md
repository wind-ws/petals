# Note
这是一个我用于学习区块链的项目,也是我的毕设

# Project
一个简单的区块链募捐系统

# Petals
暂时计划做3片花瓣,顺序是优先级, Kaspa若出了sc后就会去完善它
1. Solana Native
2. Ethereum Solidity
3. Solana Anchor
4. Kaspa (waiting)

前端使用solidjs